import React from "react";
import ReactDOM from "react-dom";
import BirdSession from "./BirdSession";

ReactDOM.render(<BirdSession />, document.getElementById("root"));

