import React from "react";
import ReactDOM from "react-dom";
import BirdSession from "./BirdSessionV3";

ReactDOM.render(<BirdSession />, document.getElementById("root"));

